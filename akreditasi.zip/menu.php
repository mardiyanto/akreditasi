  <ul class="sidebar-menu">
  <li>
              <a href='index.php?aksi=home'>
                <i class='fa fa-dashboard'></i> <span>Dashboard</span> 
              </a> 
 </li>
     <li >
          <a href="#">
            <i class="fa fa-mortar-board"></i> <span>Tentang Kami</span> <i class='fa fa-angle-left pull-right'></i>
    
          </a>
          <ul class="treeview-menu">
		  
 <li class='active'><a href='#'><i class='fa fa-circle-o'></i><span>Profil</span>
         </a></li>
		  <li class='active'><a href='#'><i class='fa fa-circle-o'></i><span>Galery</span>
         </a></li>
		 
          </ul>
        </li>  
 <li >
          <a href="#">
            <i class="fa fa-mortar-board"></i> <span>Login</span> <i class='fa fa-angle-left pull-right'></i>
          </a>
          <ul class="treeview-menu">
<li class='active'><a href='login.php'><i class='fa fa-circle-o'></i><span>Login</span>
         </a></li>
          </ul>
        </li>  
</ul>